/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Persistencia;

import Entidades.AdministradorEntidad;
import dto.EditarAdministradorDTO;
import dto.GuardarAdministradorDTO;
import java.util.List;

/**
 *
 * @author le0jx
 */
public interface IAdministradorDAO {
    AdministradorEntidad guardarAdministrador(GuardarAdministradorDTO registro) throws PersistenciaException;
    AdministradorEntidad editarAdministrador(EditarAdministradorDTO registro) throws PersistenciaException;
    AdministradorEntidad eliminarAdministrador(int id) throws PersistenciaException;
    AdministradorEntidad BuscarPorID(int id) throws PersistenciaException;
    List<AdministradorEntidad> listarAdministradores(String filtro) throws PersistenciaException;
}
